<?php
// $Id: template.php,v 1.1.2.1 2006/12/28 16:04:52 karens Exp $
function _phptemplate_variables($hook, $vars = NULL) {
  switch ($hook) {
    case ('page'):
    if (function_exists('phpgedview_path')) { 
      if (arg(0) == phpgedview_path()) {
        $vars['template_file'] = 'page-phpgedview';
      }
    }
    break;
  }
  return $vars;
}



