<?php
// where is phpGedView? If the phpGedView progs are in this directory then leave blank
// else point to the directory where they are.
// if you want to mix the interface modules together with phpGedView remember to rename the interface index to
// something else like pgvindex.php and then call that
// eg $def_gedbasedir = "../../phpGedView/";
$def_gedbasedir = "../../phpGedView/";
?>
