<?php
/**
* @version $Id: phpgedview.php 12 2008-02-19 14:00:45Z volschin $
* @package com_phpgedview
* @copyright (C) 2003 - 2006 Ron Field and Others
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* Joomla phpGedView component is Free Software
*/

// ensure this file is being included by a parent file
if (!defined( '_VALID_MOS' ) AND !defined('_JEXEC')) die( 'Direct Access to this location is not allowed.' );

global $username, $fullname, $email, $type, $gid;
global $database;
global $pgvpath;
global $next;

//get install path
$database->setQuery("SELECT path FROM #__phpgedview_conf");
$pgvpath = $database->loadResult();

$name = $my->username;
//start login check
if ( $name ) {
	$database->setQuery("SELECT * FROM #__users WHERE id = ". $my->id);
	$rows = $database->loadObjectList();
	$row = $rows[0];
	$username = $row->username;
	$fullname = $row->name;
	$firstlast = preg_split ("/[\s,]+/", $fullname);

  switch(sizeof($firstlast)){ 
    case 1: 
     $firstname = ''; 
     $lastname = $firstlast[0]; 
    break; 
    case 2: 
     $firstname = $firstlast[0]; 
     $lastname = $firstlast[1]; 
    break; 
    default: 
     $firstname = $firstlast[0]; 
     for ($i=1; $i<sizeof($firstlast)-1; $i++) { 
      $firstname = $firstname.' '.$firstlast[$i]; 
     } 
     $lastname = $firstlast[sizeof($firstlast)-1]; 
  } 

	$gid = $row->gid;
	$type = $row->usertype;
	$email = $row->email;
} else {
$username = $my->username;
}

if (($username != "Anonymous") and ($username != ""))
{
	//Get config settings
	$database->setQuery("SELECT * FROM #__phpgedview_conf");
	$rows = $database->loadObjectList();
	$row = $rows[0];
	$next=$pgvpath.'/modules/cms_interface/cms_login.php?'.
		'cms_username='.urlencode($my->username).'&amp;'.
		'cms_password='.urlencode($row->upwd).'&amp;'.
		'cms_firstname='.urlencode($firstname).'&amp;'.
		'cms_lastname='.urlencode($lastname).'&amp;'.
		'cms_email='.urlencode($email).'&amp;'.
		'cms_language='.urlencode($row->lang).'&amp;'.
		'cms_theme='.urlencode($row->deftheme).'&amp;'.
		'cms_contact='.urlencode($row->cmethod);
}else {
	if (!$_GET['pid']){
		$next = $pgvpath. 'index.php?logout=1';
	} else {
		session_start();
		$old_sessid = session_id();
		session_regenerate_id();
		$new_sessid = session_id();
		session_id($old_sessid);
		session_destroy();

		$next = $pgvpath. "individual.php?pid=". $_GET["pid"]."&ged=". $_GET["ged"]."&";
	}
}
/** load the html drawing class */
require_once( $mainframe->getPath( 'front_html' ) );

showWrap( $option );

function showWrap( $option ) {
	global $database, $Itemid, $mainframe, $next, $pgvpath;

	$menu =& new mosMenu( $database );
	$menu->load( $Itemid );
	$params =& new mosParameters( $menu->params );
	$params->def( 'back_button', $mainframe->getCfg( 'back_button' ) );
	$params->def( 'scrolling', 'auto' );
	$params->def( 'page_title', '0' );
	$params->def( 'pageclass_sfx', '' );
	$params->def( 'header', $menu->name );
	$params->def( 'height', '500' );
	$params->def( 'height_auto', '1' );
	$params->def( 'width', '100%' );

	//More work required
	$url = "http://".$_SERVER['SERVER_NAME']. "/". $next;

	$row = new stdClass();
	if ( $params->get( 'add' ) ) {
		// adds 'http://' if none is set
		if ( substr( $url, 0, 1 ) == '/' ) {
			// relative url in component. use server http_host.
			$row->url = 'http://'. $_SERVER['HTTP_HOST'] . $url;
		} elseif ( !strstr( $url, 'http' ) && !strstr( $url, 'https' ) ) {
			$row->url = 'http://'. $url;
		} else {
			$row->url = $url;
		}
	} else {
		$row->url = $url;
	}

	// volschin: You can specify to go to a specific gedcom in the menu parameters with gedcom=
	if ( $params->get( 'gedcom' )  != "") {
	$row->url = $row->url . "?command=gedcom&ged=" . $params->get( 'gedcom' );
	}
 	// end volschin

	if ($_GET['pid']){
	$row->url = $row->url . '?&id='. $_GET['pid']. '&ged='. $_GET['ged'];
	}

	// auto height control
	if ( $params->def( 'height_auto' ) ) {
		$row->load = 'onload="iFrameHeight()"';
	} else {
		$row->load = '';
	}

  $mainframe->SetPageTitle($menu->name);
	HTML_wrapper::displayWrap( $row, $params, $menu );
}

?>

